<?php
/**
 * Created by PhpStorm.
 * User: demon
 * Date: 22.05.2019
 * Time: 17:54
 */

namespace App\Exceptions;


class AccessDeniedException extends \Exception
{

}