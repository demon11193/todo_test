<?php
/**
 * Created by PhpStorm.
 * User: demon
 * Date: 22.05.2019
 * Time: 17:51
 */
namespace App\Exceptions;

class NoFindPageException extends \Exception
{

}