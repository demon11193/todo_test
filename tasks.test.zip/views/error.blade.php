@extends('layouts.app')

@section('content')

    <h3 style="margin-top: 10px;">{{$error}}</h3>

@endsection