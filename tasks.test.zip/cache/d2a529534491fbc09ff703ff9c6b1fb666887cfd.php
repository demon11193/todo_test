<?php $__env->startSection('content'); ?>

    <h1><?php echo e(is_null($task->id)?'Создание задачи':'Редактирование задачи #' . $task->id); ?></h1>
    <form action="/tasks<?php echo e(is_null($task->id)?'':'/'.$task->id); ?>" method="post">
        <div class="form-group">
            <label>Текст</label>
            <textarea class="form-control" name="content"><?php echo e($task->content); ?></textarea>
        </div>
        <div class="form-group form-check">
            <label class="form-check-label">
                <input type="checkbox" class="form-check-input"
                       value="1" name="is_finished" <?php echo e($task->is_finished?'checked':''); ?>/> Выполнено?
            </label>
        </div>
        <div class="form-group">
            <button class="btn btn-primary" type="submit">Сохранить</button>
            <a class="btn btn-link" href="/">Назад к списку</a>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\tasks.test\views/edit.blade.php ENDPATH**/ ?>