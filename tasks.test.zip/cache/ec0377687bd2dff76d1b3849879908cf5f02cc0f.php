<?php $__env->startSection('content'); ?>

    <h3 style="margin-top: 10px;"><?php echo e($error); ?></h3>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\tasks.test\views/error.blade.php ENDPATH**/ ?>